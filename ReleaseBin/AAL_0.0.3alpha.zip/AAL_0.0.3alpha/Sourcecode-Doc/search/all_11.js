var searchData=
[
  ['variablemanagement',['VariableManagement',['../class_variable_management.html',1,'']]]
];
