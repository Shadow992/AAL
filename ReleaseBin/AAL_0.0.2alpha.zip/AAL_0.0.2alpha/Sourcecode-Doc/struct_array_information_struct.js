var struct_array_information_struct =
[
    [ "overallArraySize", "struct_array_information_struct.html#a82918dfb81526d1ceb78397c33e91ac0", null ],
    [ "usedAalVarChunks", "struct_array_information_struct.html#a493e96c6cf7b392349422c5dd04383b7", null ],
    [ "usedValueChunks", "struct_array_information_struct.html#a2770dbd8c9b394d0f4b3b8c9f37e75a2", null ],
    [ "usedValueTypeChunks", "struct_array_information_struct.html#a9952b39a40f37d9882a7f47b4127b9d7", null ]
];