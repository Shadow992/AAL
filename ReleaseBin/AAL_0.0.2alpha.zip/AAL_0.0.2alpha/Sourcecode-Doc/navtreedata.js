var NAVTREE =
[
  [ "AAL_ByteCode_interpreter", "index.html", [
    [ "Advanced Automation Language - Interpreter Part (AAL)", "index.html", [
      [ "Reasons for developing AAL", "index.html#reasons", null ],
      [ "How does AAL work?", "index.html#explain_all_working", null ],
      [ "FAQ", "index.html#faq", [
        [ "Can we execute AutoIt-Scripts without changing anything in AAL?", "index.html#autoit", null ],
        [ "When will AAL be a serious competitor to AutoIt?", "index.html#not_ready", null ],
        [ "Why do I get some strange errors (e.g. \"segmentation-fault\" or \"XYZ throw an error of ABC\"), though my AAL-Code is correct for 100% and also works with AutoIt?", "index.html#correct_code_error", null ],
        [ "found a bug, what should I do now?", "index.html#I", null ],
        [ "I want to help by making this project better!", "index.html#want_to_help", null ],
        [ "How long took it to develop the first alpha version?", "index.html#time_taken", null ]
      ] ],
      [ "Credits and Contributions", "index.html#credits", [
        [ "Marcel Rupprecht (aka Shadow992)", "index.html#marcel_rupprecht", null ],
        [ "Community of elitepvpers.com", "index.html#elitepvpers", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_aal_variable_8h_source.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';