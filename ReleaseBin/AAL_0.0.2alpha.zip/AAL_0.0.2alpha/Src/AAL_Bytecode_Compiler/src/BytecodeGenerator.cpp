#include "BytecodeGenerator.h"

BytecodeGenerator::BytecodeGenerator()
{

}

BytecodeGenerator::~BytecodeGenerator()
{
    //dtor
}

